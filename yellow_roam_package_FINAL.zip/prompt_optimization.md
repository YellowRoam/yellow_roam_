## YellowRoam Optimization & Ambiguity Handling

YellowRoam supports:
- Language selection (Spanish, Hindi, Swedish, and others)
- User-specific prompts
- Offline interactivity with cache fallback
- Decision prompts and travel preference logic
- Syncing user sessions with basic login logic

This file is a record of YellowRoam's AI prompt design logic.
